#include "Laser.hpp"
#include <iostream>
#include "JetpackJoyride.hpp"
using namespace std;

Lasers::Lasers(SDL_Renderer *rend, SDL_Texture *ast, SDL_Rect mov) : Unit(rend, ast), mover(mov)
{
    cout << "laser created" << endl;
    src = {255, 555, 395, 35};
}

void Lasers::draw()
{
    Unit::draw(src, mover);
    // mover.x -= 2;
    animation();
    frame++;
}

void Lasers::collision(int barry_x, int barry_y)
{
    if (barry_x > mover.x - 100 && barry_x < (mover.x + mover.w + 100))
    {
        if ((barry_y < mover.y + (mover.h / 2)) && (barry_y > mover.y - (mover.h / 2)))
        {
            cout << "Barry collided with the laser" << endl;
        }
    }
}

Lasers::~Lasers()
{
    cout << "Laser destroyed" << endl;
}

bool Lasers::delete_item()
{
    if (mover.x < -300)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void Lasers::animation()
{
    if (frame == 1 * frame_speed)
    {
        src = {255, 555, 395, 35};
    }
    else if (frame == 2 * frame_speed)
    {
        src = {265, 496, 375, 35};
        frame = 0;
    }
}