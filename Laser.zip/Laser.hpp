#pragma once
#include "unit.hpp"
#include "barry.hpp"

#include "Killers.hpp"

class Lasers:public Killers, public Unit
{
    SDL_Rect src, mover;
    int frame = 0;

    public:
    Lasers(SDL_Renderer* rend, SDL_Texture* ast, SDL_Rect mov);
    void draw();

    int laser_x = mover.x;

    void collision(int barry_x, int barry_y) override;

    void animation();

    ~Lasers();

    bool delete_item() override;
};